BCA305P AS02 – MongoDB Lab Sheet 3
This ZIP contains the complete PDF answers for all 15 questions.
Open the PDF and run the MongoDB Shell (mongosh) commands question by question.
Note: Question 11 requires MongoDB running as a replica set or sharded cluster for transactions.
Question 12: Replace the sample ObjectId with the actual notification _id before running updateOne.
