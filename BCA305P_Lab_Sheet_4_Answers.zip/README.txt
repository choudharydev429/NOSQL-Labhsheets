BCA305P - NOSQL DATABASE DESIGN - LAB SHEET 4
Contents:
- BCA305P_Lab_Sheet_4_Answers.pdf: Answers to all 15 questions from the supplied two-page lab sheet.

The PDF contains practical Apache HBase shell and Apache Cassandra CQL examples, with brief explanations. Installation examples assume an Ubuntu/Linux lab environment. Adjust versions, paths, service commands, and Cassandra datacenter names to match your installation.
